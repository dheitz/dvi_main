# Contributor's Guide

All contributions should be in the form of a PR with the maintainer (`avinash_nonholonomy`) tagged. If you aren't sure if something is worth a patch, start by creating an issue.

## Code of Conduct
The [RISE Code of Conduct](https://wiki.riseproject.dev/display/HOME/Code+of+Conduct) is a good model for what we should use on this project, especially as it is for a RISC-V organization.

## Language Consistency/Style Guide
For any files and documents:
* Use proper English capitalization and grammar where at all possible (specifically in comments.)
* Avoid exclusionary language where possible:
  * Use main/secondary instead of master/slave.
  * Use accept/block lists instead of white/black lists.
* Where available, run a linter to make sure style is passed! 
  * Some cases will not make sense to exactly fit the style guide, put a noqa comment (e.g. `// noqa`) as a flag to tell linting tools not to parse that line.
  * TODO(avinash) - linting instructions/tests.

### (System)Verilog
* One module per file.
* 2 spaces per tab.
* Add a timescale and default_nettype directives to the top of every file.
* As not all tools support sv packages, use header guards in any non-module sv files.
* Constants and parameters should be all caps.
* Net names should use full words unless it is a standard abbreviation:
  * `ena` - enable
  * `clk` - clock
  * `rst` - reset
  * `wr`  - write
  * `rd`  - read
* Active low net naming convention:
  * Prefer suffixed `b` instead of a prefixed `n`.
    * e.g. `csb` - chip select bar, `rstb` - reset bar.
* Where possible use `always_comb` instead of `assign`.
  * Exception: `assign` should still be used for tristates (`assign tri = ena ? tri_in : 1'bz`).
* Avoid using ternary/mux operator `?` with `typedef` nets (many tools do not support implicit casting which breaks that). Use an `if`/`else` or `case` statement instead.
* Used named ports/parameters (e.g. `.ena(wr_ena)`) instead of ordered ports.
* Prefer the following module declaration convention:
```
  module foo(net0, net1, net2);

  parameter N = 32;
  input [N-1:0] net0;
  output net1;
  output [N-1:0] net2;

``` 
  * This is the assumption some of the automated scripts use to parse modules, this preference can be relaxed once the scripts are updated to parse other module instantiation methods.


### Makefiles
* `make` actually requires tabs, not spaces, make sure your editor respects this.

### Python
* 4 spaces per tab (per pep-8).
* Do not use `pip` outside of a virtual environment (`venv`).
* Prefer native python where possible, exceptions are:
  * `click` for command line interfacing/argument parsing.
  

### C/C++ 
* TODO(avinash) pick [llvm](https://llvm.org/docs/CodingStandards.html) or [Google](https://google.github.io/styleguide/cppguide.html) standards.