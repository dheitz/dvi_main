# Exploring using docker for containerized fpga lab support

## Building Ubuntu 22.04 container

Note, running things with docker is the same as running things as root, so *always* read Dockerfiles as a sanity check before building anything!

You also might want to edit any `make -jN` arguments to make sure that it's using the right number of cores for your system.

```bash
# To build:
docker build Ubuntu  -t avinash:cafe-ubuntu2204

# To run: REPLACE $USER with your USERNAME if you are using a different shell.
docker run -it -v /tmp/.X11-unix:/tmp/.X11-unix -v $HOME/user/embedded/xilinx/:/opt/xilinx avinash:cafe-ubuntu2204  /bin/bash 

# For debugging
docker run -it --net=host -v /tmp/.X11-unix:/tmp/.X11-unix -v /home/avinash/src:/home/cafe/src avinash:cafe-ubuntu2204  /bin/bash 
docker run -it --net=host -v /tmp/.X11-unix:/tmp/.X11-unix -v /mnt/bulk/avinash/embedded/xilinx/fa22/smaller_install:/opt/xilinx -v /home/avinash/src:/home/cafe/src avinash:cafe-ubuntu2204  /bin/bash 

```

### Version check:
Ends up with:
gtkwave: 3.3.104-2build1
verilator: 4.038-1

# Misc. notes
Copying the whole xilinx directory with permissions is *not* something docker really supports, but that's okay because you can just mount it as a volume.

I did have the idea of generating a list of x's before the copy:
```bash
find ./ -name bin -exec chmod -R a+rx {} \;
find ./ -name "*.jar" -exec chmod -R a+rx {} \;

```
And then you could manually chmod a+rx those same files later... But wasn't worth it. 
