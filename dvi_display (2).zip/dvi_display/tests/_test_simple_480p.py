import cocotb
import random

from cocotb.clock import Clock
from cocotb.triggers import Timer, RisingEdge, FallingEdge, ClockCycles



# key things
# dut.wire.value is not an int but something else but to get an int its dut.wire.value.integer

# i didnt end up adding a bug to the verilog file b/c there was one that i found with this code
# but it turned out to be more of a quirk than a bug b/c if i fixed it or not it still worked

# so i flipped the bit at line 68 to keep i ready high

# there was no tristate functionality built into cocotb (why dear god why)
# so i found a github https://github.com/SpinalHDL/CocotbLib/blob/master/TriState.py
#but that didnt work
# i then decided there was no way to do it right with a tristate after 3 hours with it
hpixels = 640
vpixels = 480

@cocotb.test()
async def test_main(dut:cocotb.handle.HierarchyObject):
    # start with the device as the main
    clock = Clock(dut.clk, 5, units="ns")
    cocotb.start_soon(clock.start())
    dut.rst.value = 1

    # let the rst settle a bit
    for i in range(2): 
        await FallingEdge(dut.clk)
    # check the data is not being sent
    assert dut.sx.value == 0, "x should be 0"
    assert dut.sy.value == 0, "y should be 0" 
    assert dut.hsync.value == 0, " in pixels should not have hsync going"
    assert dut.hsync.value == 0, " in pixels should not have hsync going"
    dut.rst.value = 0


    
    
    for _ in range(50):
        # wait for i ready
        i = 0
        while (dut.i_ready.value==0):
            posstr = " cooldown cycle "+str(i)
            #print(dut.scl.value)
            assert dut.scl.value == 1, "scl not high in"+posstr
            #assert dut.o_valid.value == 0, "output data should not be valid in "+posstr
            i += 1
            assert i<400, "stuck with i ready not going high after rst"
            await FallingEdge(dut.clk)

        #give it some more clock
        for _ in range(random.randint(1,16)):
            await FallingEdge(dut.clk)
            print("waiting a clock cycle to test the delay or iready")
            assert dut.scl.value == 1, "confirm scl not high in ready"
            assert dut.i_ready.value == 1, "confirm input is ready"
        # give it data
        addr = random.randint(0,127)
        data = random.randint(0,255)
        mode = random.randint(0,1)
        print("pinging to addr",addr)
        print("in mode",mode)
        print("data byte",data)
        dut.mode.value = mode
        dut.i_addr.value = addr
        if mode :
            dut.i_data.value = 0 # 1 is read
        else:
            dut.i_data.value = data # 0 is write
        dut.i_valid.value = 1 # setting this after i sent my data
        await FallingEdge(dut.clk)
        posstr = "error at idle-> start input addr = "+str(addr)+"data"+str(data)
        assert dut.scl.value == 1, "scl not high"+posstr
        assert dut.o_valid.value == 0, "output data should not be valid"+posstr
        assert dut.i_ready.value == 0, "i ready should not be ready"+posstr
        dut.i_valid.value=0 # i ready is no longer high so my data shouldnt be valid anymore
        #at this point im goint to simulate the sub device (aka not looing at the clk but scl)
        
        await FallingEdge(dut.scl)
        assert dut.sda.value == 0," start bit is not low"

        # we shoud first see the addr
        v_addr = 0
        for bit in range(7):
            await RisingEdge(dut.scl)
            posstr = "error in sending addr: "+str(addr)
            assert dut.o_valid.value == 0, "output data should not be valid"+posstr
            assert dut.i_ready.value == 0, "i ready should not be ready"+posstr
            print("recieved address bit",bit,"=",dut.sda.value.integer)
            v_addr = v_addr*2+ (dut.sda.value.integer) # this is how to get it to be an integer
        assert v_addr == addr, "address should be "+str(addr)+" but verilor gave me"+str(v_addr)

        # now i check the mode bit
        await RisingEdge(dut.scl)
        posstr = "error in sending addr: "+str(addr)
        assert dut.o_valid.value == 0, "output data should not be valid"+posstr
        assert dut.i_ready.value == 0, "i ready should not be ready"+posstr
        assert dut.sda.value == mode, "transmit mode is not set correctly should be"+str(mode)+" but is "+str(dut.sda.value)
        print("mode bit =",dut.sda.value)
        v_mode = dut.sda.value
        # wait/send the ack bit
        await FallingEdge(dut.scl)
        dut.sda.value = 0
        print(dut.sda.value)
        await FallingEdge(dut.scl)
        dut.sda.value = None#cocotb.types.Logic("Z")#"z"   # return this to the tristate

        print("post z sda =",dut.sda.value)


        #now i receive/write the data (miso)
        if v_mode == 1:
            print("sub device transmittin mode (miso)")
            v_data = data
            await FallingEdge(dut.scl)
            for bit in range(8):
                #print("bit",bit)
                await FallingEdge(dut.scl)
                posstr = "error in reading data (miso): "+str(addr)
                assert dut.o_valid.value == 0, "output data should not be valid"+posstr
                assert dut.i_ready.value == 0, "i ready should not be ready"+posstr
                dut.sda.value = int((data%(2**(8-bit)))>=2**(7-bit))
                print("sending bit",bit,"=",int((data%(2**(8-bit)))>=2**(7-bit)))
            # go back to internal style
            
            # wait/send the ack bit
            await RisingEdge(dut.scl)
            dut.sda.value = 0
            await FallingEdge(dut.scl)
            dut.sda.value = cocotb.types.Logic("Z") # return this to the tristate
            
            i = 0
            while(dut.o_valid.value==0):
                i += 1
                assert i<500, "stuck with o valid not going high after data being sent after 500 cycles."
                await RisingEdge(dut.clk)
            await RisingEdge(dut.scl)
            assert dut.o_data.value==data,"data does not match should output"+str(data)+"but outputs"+str(dut.o_data.value.integer)
        
        # mosi style
        else:
            print("sub device receiving mode (mosi)")
            v_data = 0
            for bit in range(8):
                await RisingEdge(dut.scl)
                print("post z sda =",dut.sda.value)
                posstr = "error in sending data (mosi): "+str(addr)
                assert dut.o_valid.value == 0, "output data should not be valid"+posstr
                assert dut.i_ready.value == 0, "i ready should not be ready"+posstr
                print("sent data bit",bit,"=",dut.sda.value.integer)
                v_data *= 2
                v_data += dut.sda.value.integer
            assert v_data == data, "data from fsm should be "+str(data)+" but verilog gave me"+str(v_data)

        # now we should be back to idle/stop
        #await FallingEdge(dut.clk)
    # end of for loop

    
    #TODO figure out how to test CLOCK STRETCHING


import cafe_test

def test_simple_480p():
    cafe_test.runner("simple_480p")#,["i2c_types"])