import cocotb
import random

from cocotb.clock import Clock
from cocotb.triggers import Timer, RisingEdge, FallingEdge, ClockCycles



# key things
# dut.wire.value is not an int but something else but to get an int its dut.wire.value.integer

# i didnt end up adding a bug to the verilog file b/c there was one that i found with this code
# but it turned out to be more of a quirk than a bug b/c if i fixed it or not it still worked

# so i flipped the bit at line 68 to keep i ready high

# there was no tristate functionality built into cocotb (why dear god why)
# so i found a github https://github.com/SpinalHDL/CocotbLib/blob/master/TriState.py
#but that didnt work
# i then decided there was no way to do it right with a tristate after 3 hours with it
hpixels = 640
vpixels = 480

clk_dvd = 5

@cocotb.test()
async def test_main(dut:cocotb.handle.HierarchyObject):
    # start with the device as the main
    clock = Clock(dut.clk, 5, units="ns")
    cocotb.start_soon(clock.start())
    dut.rst.value = 1

    # let the rst settle a bit
    for i in range(2): 
        await FallingEdge(dut.clk)
    # check the data is not being sent
    dut.red.value = 0
    dut.grn.value = 0
    dut.blu.value = 0
    dut.ctl.value = 0
    dut.de.value = 0
    dut.hsync.value = 0
    dut.vsync.value = 0
    dut.rst.value = 0
    last_clk = 0
    for _ in range(4):
        for _ in range(clk_dvd-1):
            await RisingEdge(dut.clk)
            assert dut.pixel_clk.value == last_clk, "pixel clock shifted to early"
        last_clk = (last_clk+1)%2
        await RisingEdge(dut.clk)
        assert dut.pixel_clk.value == last_clk, "pixel clock shifted to late"    


    dut.rst.value = 1
    # let the rst settle a bit
    for i in range(2): 
        await FallingEdge(dut.clk)
    # check the data is not being sent
    dut.rst.value = 0



import cafe_test

def test_tmds_controller():
    cafe_test.runner("tmds_controller",["tmds_encoder","OutputSERDES"])