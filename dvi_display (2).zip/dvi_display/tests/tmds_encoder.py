# unused at this point but nessicary to test the system


def encode_tmds(count, data,de,ctl0,clt1):
    """ Encode 8-bit data using TMDS encoding rules, producing a 10-bit output. """
    running_disparity = 0

    def count_ones(bits):
        """ Count ones between consecutive bits in a byte. """
        transitions = 0
        for i in range(len(bits)):
            if bits[i]:
                transitions += 1
        return transitions

    def apply_xor_or_xnor(bits, use_xnor):
        """ Apply XOR or XNOR between consecutive bits, starting from the first bit. """
        result = [0,0,0,0,0,0,0,0]
        result[7] = bits[7]  # The first bit remains as is
        for i in range(len(bits)-2,-1,-1):# bits[1:]
            #print(i, bits[i])
            if use_xnor:
                result[i] = (int(not(bits[i] ^ result[i + 1])))
            else:
                result[i] = (bits[i] ^ result[i + 1])
            #print(i, bits[i],result)
        return result

    if not de:
        count = 0
        if ctl0:
            if clt1:
                return count,[1,1,0,1,0,1,0,1,0,1]
            else:
                return count,[1,1,0,1,0,1,0,1,0,0]
        else:
            if clt1:
                return count,[0,0,1,0,1,0,1,0,1,0]
            else:
                return count,[0,0,1,0,1,0,1,0,1,1]

    # Convert data to binary
    input_bits = [(data >> i) & 1 for i in range(8)][::-1]
    #print(input_bits)

    # Stage 1: XOR or XNOR application
    xnor_result = apply_xor_or_xnor(input_bits, True)
    xor_result = apply_xor_or_xnor(input_bits, False)
    print(count_ones(input_bits),xnor_result,xor_result)
    if (count_ones(input_bits)>4 or (count_ones(input_bits)==4 and input_bits[7]==0)):
        stage1_output = xnor_result
        stage1_flag = 0  # Indicating XNOR was used
    else:
        stage1_output = xor_result
        stage1_flag = 1  # Indicating XOR was used
    
    # Construct the 9-bit code
    stage1_final_code =[stage1_flag] + stage1_output
    not_stage1_final_code = [int(not bit) for bit in stage1_final_code]
    print(stage1_final_code,stage1_final_code[1:9])
    # Update running disparity based on the initial input
    ones_count = stage1_output.count(1)
    zeros_count = 8 - ones_count
    print(ones_count,zeros_count)



    # Stage 2: Invert data if necessary
    if count == 0 or ones_count==zeros_count:
        if stage1_final_code[0]:
            output = [not_stage1_final_code[0],stage1_final_code[0]]+stage1_final_code[1:9]
            count += ones_count-zeros_count
            print("stageone final code[0] = 1")
        else:
            output = [not_stage1_final_code[0],stage1_final_code[0]]+not_stage1_final_code[1:9]
            count += zeros_count-ones_count
            print("stageone final code[0] = 0")
        #print(count)
        return count,output

    if (count>0 and ones_count>zeros_count) or (count<0 and ones_count<zeros_count):
        output = [1,stage1_final_code[0]]+not_stage1_final_code[1:9]
        count += 2*stage1_final_code[0] + zeros_count-ones_count
        print("cond_not_balanced_2 = 1")
        #print(count)
        return count,output
    
    output = [0,stage1_final_code[0]]+stage1_final_code[1:9]
    count += 2*not_stage1_final_code[0] + ones_count-zeros_count
    print("cond_not_balanced_2 = 0")
    #print(2*stage1_final_code[0] + ones_count-zeros_count)
    return count,output

# Example usage:
if __name__ == "__main__":
    count = 8
    data = 255  # Example 8-bit data
    count, encoded_data = encode_tmds(count, data,1,1,1)
    print(count)
    print("Encoded Data:", ''.join(str(bit) for bit in encoded_data))  # Show 10-bit output
