import cocotb
import random

from cocotb.clock import Clock
from cocotb.triggers import Timer, RisingEdge, FallingEdge, ClockCycles

test_len = 10000

count = 0



def encode_tmds(count, data,de,ctl0,clt1):
    """ Encode 8-bit data using TMDS encoding rules, producing a 10-bit output. """
    running_disparity = 0

    def count_ones(bits):
        """ Count ones between consecutive bits in a byte. """
        transitions = 0
        for i in range(len(bits)):
            if bits[i]:
                transitions += 1
        return transitions

    def apply_xor_or_xnor(bits, use_xnor):
        """ Apply XOR or XNOR between consecutive bits, starting from the first bit. """
        result = [0,0,0,0,0,0,0,0]
        result[7] = bits[7]  # The first bit remains as is
        for i in range(len(bits)-2,-1,-1):# bits[1:]
            #print(i, bits[i])
            if use_xnor:
                result[i] = (int(not(bits[i] ^ result[i + 1])))
            else:
                result[i] = (bits[i] ^ result[i + 1])
            #print(i, bits[i],result)
        return result

    if not de:
        count = 0
        if ctl0:
            if clt1:
                return count,[1,1,0,1,0,1,0,1,0,1]
            else:
                return count,[1,1,0,1,0,1,0,1,0,0]
        else:
            if clt1:
                return count,[0,0,1,0,1,0,1,0,1,0]
            else:
                return count,[0,0,1,0,1,0,1,0,1,1]

    # Convert data to binary
    input_bits = [(data >> i) & 1 for i in range(8)][::-1]
    #print(input_bits)

    # Stage 1: XOR or XNOR application
    xnor_result = apply_xor_or_xnor(input_bits, True)
    xor_result = apply_xor_or_xnor(input_bits, False)
    #print(count_ones(input_bits),xnor_result,xor_result)
    if (count_ones(input_bits)>4 or (count_ones(input_bits)==4 and input_bits[7]==0)):
        stage1_output = xnor_result
        stage1_flag = 0  # Indicating XNOR was used
    else:
        stage1_output = xor_result
        stage1_flag = 1  # Indicating XOR was used
    
    # Construct the 9-bit code
    stage1_final_code =[stage1_flag] + stage1_output
    not_stage1_final_code = [int(not bit) for bit in stage1_final_code]
    #print(stage1_final_code,stage1_final_code[1:9])
    # Update running disparity based on the initial input
    ones_count = stage1_output.count(1)
    zeros_count = 8 - ones_count
    #print(ones_count,zeros_count)



    # Stage 2: Invert data if necessary
    if count == 0 or ones_count==zeros_count:
        if stage1_final_code[0]:
            output = [not_stage1_final_code[0],stage1_final_code[0]]+stage1_final_code[1:9]
            count += ones_count-zeros_count
            print("stageone final code[0] = 1")
        else:
            output = [not_stage1_final_code[0],stage1_final_code[0]]+not_stage1_final_code[1:9]
            count += zeros_count-ones_count
        #print(count)
        return count,output

    if (count>0 and ones_count>zeros_count) or (count<0 and ones_count<zeros_count):
        output = [1,stage1_final_code[0]]+not_stage1_final_code[1:9]
        count += 2*stage1_final_code[0] + zeros_count-ones_count
        #print(count)
        return count,output
    
    output = [0,stage1_final_code[0]]+stage1_final_code[1:9]
    count += 2*not_stage1_final_code[0] + ones_count-zeros_count
    #print(2*stage1_final_code[0] + ones_count-zeros_count)
    return count,output


# Example usage:
# data = 0b11010110  # Example 8-bit data
# encoded_data = encode_tmds(data)
# print("Encoded Data:", ''.join(str(bit) for bit in encoded_data))  # Show 10-bit output

def to_signed(value,l):
    value = value.to_signed()
    upper = 2**(l-1)
    if value>=upper:
        return (2**l)-value
    return value


@cocotb.test()
async def test_main(dut:cocotb.handle.HierarchyObject):
    # start with the device as the main
    clock = Clock(dut.clk, 5, units="ns")
    cocotb.start_soon(clock.start())
    dut.rst.value = 1

    # let the rst settle a bit
    for i in range(2): 
        await FallingEdge(dut.clk)
    # check the data is not being sent
    assert dut.data_out.value == 0, "dataout should be 0"

    dut.rst.value = 0
    dut.data.value = 0
    dut.de.value = 1
    dut.ctl0.value = 0
    dut.ctl1.value = 0
    count = 0

    input_list = [i for i in range(256)]+[0,1,2,3]
    counts = []
    output_correct_list = []
    for i,input in enumerate(input_list):
        count, correct_output = encode_tmds(count,input,de=1,clt1=1,ctl0=1)
        counts.append(count)
        output_correct_list.append(correct_output)
        dut.data.value = input
        print("_",40*(str(i)+"_"))
        print("data_out",dut.data_out.value)
        print("data_1",dut.data_1.value)
        print("bit_sum",dut.bit_sum.value)
        print("xor_data",dut.xor_data.value)
        print("xnor_data",dut.xnor_data.value)
        print("tm_data",dut.tm_data.value)
        print("bit_sum_tm_data_n1",dut.bit_sum_tm_data_n1.value)
        print("tm_data_1",dut.tm_data_1.value)
        print("cond_balanced_2",dut.cond_balanced_2.value)
        print("cond_not_balanced_2",dut.cond_not_balanced_2.value)
        print("dc_bias_2",dut.dc_bias_2.value)
        print("count",dut.count.value)
        print("count_1",dut.count_1.value)

        print("data_out_raw",dut.data_out_raw.value)
        print("data_out",dut.data_out.value)

        shift = 3
        if i>=shift:
            out = 0
            for bit in output_correct_list[i-shift]:
                out = (out << 1) | bit
            #assert dut.count.value == 0, "dataout should be 0"
            #print("checking input",input_list[i-shift],
            #      "expect",''.join(str(bit) for bit in output_correct_list[i-shift]))
            out_str = ("dataout should be "+
                                    ''.join(str(bit) for bit in output_correct_list[i-shift])+
                                    " ("+str(out)+") with output count: "+
                                    str(counts[i-shift])+" with input "+str(input_list[i-shift]))
            print(out_str)
            print(counts[-4:],dut.count_1.value.signed_integer,dut.count.value.signed_integer)
            #print(to_signed(dut.count_1,5))#.to_signed())
            assert dut.count_1.value.signed_integer == counts[i-shift],  "output count missmatch"
            #assert dut.count.value.signed_integer == counts[i-shift+1], "output count missmatch"
            assert dut.data_out.value == out,out_str

        await RisingEdge(dut.clk)
        print("rising edge")
    
        await FallingEdge(dut.clk)
        print("falling edge")
        


import cafe_test

def test_tmds_encoder():
    cafe_test.runner("tmds_encoder",["bit_count"])
