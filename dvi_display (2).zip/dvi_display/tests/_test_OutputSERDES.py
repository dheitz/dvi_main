@cocotb.test()
async def test_output_serdes(dut):
    cocotb.start_soon(Clock(dut.PixelClk, 10, units='ns').start())  # 100 MHz clock
    cocotb.start_soon(Clock(dut.SerialClk, 2, units='ns').start())  # 500 MHz DDR clock

    dut.aRst <= 1
    await Timer(20, units='ns')
    dut.aRst <= 0
    await Timer(20, units='ns')

    for _ in range(5):
        test_data = random.getrandbits(dut.kParallelWidth.value)
        dut.pDataOut <= test_data
        await RisingEdge(dut.PixelClk)  # Synchronize with the pixel clock

        expected_serial_output = compute_expected_output(test_data, dut.kParallelWidth.value)
        
        # Wait for data to be serialized
        for expected_bit in expected_serial_output:
            await RisingEdge(dut.SerialClk)  # Sync with Serial Clock
            actual_p = int(dut.sDataOut_p.value)
            actual_n = int(dut.sDataOut_n.value)
            assert actual_p == expected_bit, f"Output mismatch on sDataOut_p: expected {expected_bit}, got {actual_p}"
            assert actual_n == (1 - expected_bit), f"Output mismatch on sDataOut_n: expected {1 - expected_bit}, got {actual_n}"
            cocotb.log.info(f"Checked bit: expected {expected_bit}, got p: {actual_p}, n: {actual_n}")


def compute_expected_output(pDataOut, width):
    # Assuming the MSB of pDataOut comes out first, and every bit is output twice (DDR)
    output_stream = []
    for i in range(width-1, -1, -1):
        bit = (pDataOut >> i) & 1
        output_stream.extend([bit, bit])  # Extend by repeating the bit because of DDR
    return output_stream


def test_OutputSERDES():
    """ Configure and run the OutputSERDES cocotb tests using cafe_test. """
    cafe_test.runner("OutputSERDES", parameters={"kParallelWidth": 10})
