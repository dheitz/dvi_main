import cocotb
import random

from cocotb.clock import Clock
from cocotb.triggers import Timer, RisingEdge, FallingEdge, ClockCycles
from pprint import pprint


# key things
# dut.wire.value is not an int but something else but to get an int its dut.wire.value.integer

# i didnt end up adding a bug to the verilog file b/c there was one that i found with this code
# but it turned out to be more of a quirk than a bug b/c if i fixed it or not it still worked

# so i flipped the bit at line 68 to keep i ready high

# there was no tristate functionality built into cocotb (why dear god why)
# so i found a github https://github.com/SpinalHDL/CocotbLib/blob/master/TriState.py
#but that didnt work
# i then decided there was no way to do it right with a tristate after 3 hours with it


@cocotb.test()
async def bit_count_main(dut:cocotb.handle.HierarchyObject):
    """iter through the inputs and ena"""
    print(dut)
    for input in range((2**16-1)):
        print("setting input to:",input)
        dut.__getattr__("u").value = input#cant use .in b/c of python being python
        await Timer(1,'ns')# have to wait for the sim time to go by 

        #the inputs and outputs are NOT lists they are ints for multi bit vars
        assert dut.sum.value == bin(input)[2:].count("1")

    print("test finished")


import cafe_test

def test_bit_count():
    cafe_test.runner("bit_count")#,["i2c_types"])