# Open source install guide

Everything here is not 100% tested.

## Yosys Install
- Official [docs](http://yosyshq.net/yosys/documentation.html)
- [github](https://github.com/YosysHQ/yosys) seems more up to date
- there is also SymbiYosys (formal verification tool) [site](https://symbiyosys.readthedocs.io/en/latest/) [github](https://github.com/YosysHQ/sby)
- install options
  - professional level: [tabby cad suite](https://www.yosyshq.com/tabby-cad-datasheet)
  - open source only binaries: [oss cad suite](https://github.com/YosysHQ/oss-cad-suite-build)
    - might be missing SystemVerilog support?
  - from scratch [instructions](https://github.com/YosysHQ/oss-cad-suite-build#installation)

Trying the oss CAD suite? Option 
- download archive. Using the 20221027 version for this test, assume will need later than that from now on.
- add something like this to your bashrc:
```bash
function setup_oss_cad_suite(){
    source ${HOME}/embedded/oss-cad-suite/environment
}
```
- hm, seems to work well to get verilator, gtkwave, and iverilog all installed, at bleeding edge versions no less. Could simplify that part of the install for the future.

- this could be the killer feature for it: you can generate full block diagrams. see `examples/yosys_testing/analysis.ys` for an example
- with the right liberty file you can constrain the types of units used for synthesis. I found a cmos that is nand/nor and flip flop only!
  - [liberty file structure](https://www.vlsisystemdesign.com/worried-about-liberty-basics-lets-start-from-ground-zero/)
  - [blog post onb timing](https://vlsimaster.com/liberty-file/) 
  - [ysosys examples](https://github.com/YosysHQ/yosys/tree/master/examples) has some files.

## xilinx capable tools
The big one is[nextpnr-xilinx](https://github.com/gatecat/nextpnr-xilinx)






