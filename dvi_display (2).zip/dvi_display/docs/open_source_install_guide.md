# Using OSS CAD Suite for all open source tools

Follow the instructions on the official [guide](https://www.opensourceagenda.com/projects/oss-cad-suite-build#Installation). Should work on any OS (linux is most supported though).

Checklist:
* [ ] Download the appropriate archive from the releases page. Reach out if you aren't sure which version to download.
    * Note: last checked with the 20230703 version. 
* [ ] 


The following is just an example:
```bash

```
### Resources
* Basic command line usage.
* Understanding shell environments and PATH variables.

