# Install Guide

Software assumes that you are running a relatively modern Linux distribution. It should work fine in a Virtual Machine (VM) or Windows Subysystem for Linux (WSL) (you may need to install the Digilent tools in native Windows to be able to flash FPGAs). The open source tools should run fine on macos, but Vivado in particular might be tricky. There is a [guide to using Rosetta to run Vivado on M-series macs](https://gist.github.com/sohnryang/ca5d2512f7c6e0bab87843dbf1a3708f), but if you go that route expect some issues. Simulation can run on any OS, but FPGA related tools are only supported on Linux and Windows. *The following assumes you are running a relevantly recent Debian-based Linux distribution*.

A note on philosophy - there are a lot of techniques to batch together the install of all of these tools (virtual machines, Docker/containers, build scripts, etc.), but a large part of being a good embedded engineer is know how to maintain and install a large set of tools with low to minimal documentation. If you are new to Linux command line/bash installation I recommend you work through the following tutorials before proceeding:
  - [Command Line for Beginners](https://ubuntu.com/tutorials/command-line-for-beginners#1-overview).
  - Get used to [Tab Completion](https://www.howtogeek.com/195207/use-tab-completion-to-type-commands-faster-on-any-operating-system/) - it saves you time and typos!
  - [Reverse Search](https://codeburst.io/use-reverse-i-search-to-quickly-navigate-through-your-history-917f4d7ffd37) - a very powerful tool for when you're rapidly iterating - let's you search your history and quickly re-run commands you've run before.
  - [A guide to bashrc](https://www.routerhosting.com/knowledge-base/what-is-linux-bashrc-and-how-to-use-it-full-guide/) - how you customize your command line (aka shell).
  - Last but not least, you can get information on most commands by typing `man command` or `command --help`.

## Vocabulary/Acronyms
* HDL: Hardware Description Language. The two biggest ones in industry are VHDL and SystemVerilog. A way to use text and some software/coding ideas to describe hardware circuits and systems.
* Time-based simulation: Generate what the (typically binary) voltage waveforms look like for a given test or module.
* Testbench: A set of software that tests an HDL module. Can be written in a higher level form of HDL or an entirely different language, like python.
* UUT/DUT: Unit Under Test or Device Under Test. A common abbreviation for the module that is being tested.

## OS Level Packages and Helpers
```bash
# Build Tools
sudo apt-get update
sudo apt-get upgrade
# libtinfo5 and libxtst6 are for vivado, the rest are just good system level things to have.
sudo apt-get install build-essential nano python3 libusb-1.0.0 git libtinfo5 libxtst6
# Note, we are going to double install this so we have it available even without the OSS tools.
sudo apt-get install python3-bitstring
# Allows you to connect to hardware devices.
sudo adduser $USER dialout
```

## Open Source Tools and Setup.

The bulk of the tools are available via the Open Source CAD Suite, which will give us access to the following required tools (in addition to many more useful packages):
* `iverilog` (aka Icarus Verilog): Runs time-based simulations of our hardware.
* `gtkwave`: A gui program that lets us view waveforms generated from a simulation for debugging and analysis.
* `verilator`: Another HDL simulation tool that can be far faster than Icarus Verilog, though it takes more work to set up. We will primarily use it for its linting support (highlighting of warnings/errros before running a simulation).


Check the instructions on the official [guide](https://www.opensourceagenda.com/projects/oss-cad-suite-build#Installation) for the OSS CAD Suite. Should work on any OS (linux is most supported though).
* [ ] Download the appropriate archive from the releases page. You probably want `linux-x64`, ask for help if you are running on macOS on an M processor and not virtualizing.
* [ ] Create a directory without spaces and move the file there. I use `~/embedded` to store all of my EE software, but as long as your remember the location you should be okay. The date used below will vary!
```bash
mkdir -p ~/embedded/
mv ~/Downloads/oss-cad-suite-linux-x64-20230907.tgz ~/embedded
cd ~/embedded
tar -xvzf oss-cad-suite-linux-x64-20230907.tgz 
rm oss-cad-suite-linux-x64-20230907.tgz 
```

### Text Editing and Linting
I highly recommend using a text editor with linting support, ([vscode](https://code.visualstudio.com/)) is the most supported for this class. To set up linting:

  * [ ] Install the `mshr-h.veriloghdl` vscode extension. You can either search for it in the gui, or just run: `code --install-extension mshr-h.veriloghdl` from the command line.
  * [ ] Configure `vscode` to use Verilator.
    * [ ] Open the settings with `Ctrl+,`.
    * [ ] Search for `verilog.linting.linter`, select `verilator`.
    * [ ] Search for `verilog.linting.verilator.arguments`, and set it to read:
    `--timing -Ihdl -Isystems`.
      * This tells verilator where included files might be located, and turns off some timing warnings.
      * As projects get more complicated you may want to add other include paths to this section.
    * [ ] Search for `verilog.linting.verilator.runAtFileLocation` and make sure it is *not* selected.
  * [ ] Check that that linting works by opening `hdl/syntax_bugs.sv`. You should see a few red error lines and yellow error lines, which if you hover over them will suggest how you might fix them.
  * *Note* - Not all warnings (yellow lines) are bad, read through the message and ask if you aren't sure if it is an issue or not!

## Continuous Integration
The system running system integration needs to have access to `iverilog`, `verilator`, `pytest`, `cocotb` and `cocotb-test`. You can use either the OSS-CAD-Suite or your OS's package manager to install the non-python dependencies. I recommend installing the python dependencies for continuous integration and testing using a Python virtual environment (`venv`) for maximum portability.

First time `venv` setup. Run once.
```bash
python -m venv ./.venv
source .venv/bin/activate
pip3 install -r requirements.txt 
```

If `requirements.txt` has changed, you may need to re-run the pip install with `pip install --upgrade --force-reinstall -r requirements.txt`.

### Running tests locally
Every time you want to run continuous integration style tests:
```bash
source .venv/bin/activate
# Run all tests:
pytest tests/

# See what tests have been created:
pytest --collect-only tests/

# Run a specific test, with verbose outputs and waveform capture:
WAVES=1 pytest -o log_cli=True -k test_rotary_encoder
# Wave files will be in the sim_build directory, e.g. ./sim_build/edge_detector.fst

# Run a specific test that passes parameters to a module:
# TODO(avinash)
```
### Setting up CI on github

TODO(avinash)

# Vendor Specific FPGA Tools


## Digilent Tools (optional, but recommended)

Go to the digilent [adept 2](https://digilent.com/reference/software/adept/start) website, create an account, and download the correct `runtime` and `utilities` packages for your system. For Debian-based linxues you should be able to install as follows (exact version numbers may vary). 
```bash
sudo dpkg -i digilent.adept.runtime_2.4.1-amd64.deb
sudo dpkg -i digilent.adept.utilities_2.4.1-amd64.deb
```
## Proprietary Software (AMD Vivado)
Make sure you have at least 40GB of free space, and can leave your computer connected to the internet for a while. 

### Option - Custom Install from External Drive
IMPORTANT - plug the drive into a USB3.0 or faster port! This will take ages on a slower one. 
* [ ] Mount the drive (might happen automatically in ubuntu)
* [ ] Open a terminal in the drive's top level directory. You should see a script `custom_install.sh`
* [ ] Run `custom_install.sh /path/to/installing/vivado`. I used `~/embedded/xilinx/` for this guide. You may need to run this as root (use `sudo` in front of the command), depending on how you mounted the drive.
* [ ] Safely unmount the drive. If you mounted through the GUI, you should be able to hit th eject button. If you did it from the command line, a `sudo umount /path/to/mount/point` should work. Ask an instructor if you are unsure!
* [ ] Change the owner and group of the folders in the drive to match your system. Might need to be done on root, again depending on how you mounted it. I recommend replacing `$USER` below with your actual username if you run this as root.
  `chown -R $USER /path/to/install`
  `chgrp -R $USER /path/to/install`
* [ ] Proceed to environment setup, but be especially careful with what path these tools got installed to. 

### Option - Full Web Install
If you have the ~61GB of free space the web installer has some massive improvements so I recommend you just wait that out instead of trying to copy files (you may have heard horror stories from prior years). The name also changed from Xilinx to AMD this year (completed corporate acquisition), but you will probably see a lot of references to Xilinx.

Checklist:
  * [ ] Create an account on [amd.com](amd.com). You will need to click the little avatar icon on the top and then select Create Account.
  * [ ] Download the Linux 2023.1 version of the "Unified Installer" from [here](https://www.xilinx.com/support/download.html)
    * [ ] Optional, find out how to check the download hash or digest.
  * [ ] Create a directory for your install, I like `~/embedded/xilinx/`.
    ```mkdir -p ~/embedded/xilinx```
  * [ ] Run the installer:
  ```bash
    cd ~/Downloads
    # Exact numbers here may vary. Makes the file executable.
    chmod +x Xilinx_Unified_2023.1_0507_1903_Lin64.bin
    ./Xilinx_Unified_2023.1_0507_1903_Lin64.bin
  ```
    * [ ] Log in using the account you created earlier.
    * [ ] Select Download and Install Now. Click Next.
    * [ ] Select Vivado, click Next.
    * [ ] Select Vivado ML Standard, click Next.
    * [ ] Uncheck Vitis  Model Composer (unless you are interested in DSP *and* have extra hard disk space).
    * [ ] Uncheck Kria SOMS, SoCs, UltraScale, UltraScale+ (only 7 Series should be selected). Click Next.
    * [ ] Select the desired install path, for me it was `/home/avinash/embedded/xilinx/`, you sadly can't use `~` or `$HOME` here.
    * [ ] Hit install.


## Environment Setup
I highly recommend having a command to set up your environment so that these tools aren't always available (it can make sure it doesn't interfere with other software for other classes). To do this, you will need to edit your `~/.bashrc` file with your favorite text editor, and add this, making sure to change the paths to wherever you installed the tools!

_UPDATED 2023.09.15_

```bash
function setup_cafe(){
  # Enable open source tools.
  source ~/embedded/oss-cad-suite/environment

  # Enable Xilinx.
 	export XILINX_INSTALL_PATH="${HOME}/embedded/xilinx/"
  VERSION="2023.1"
  export VIVADO_PATH=${XILINX_INSTALL_PATH}/Vivado/${VERSION}/
  # Calls the Xilinx setup scripts so that you can run the tools.
  # Sourcing settings64.sh doesn't work for the hard drive install! Instead do this:
  export PATH="${VIVADO_PATH}/bin:$PATH"
  # source ${VIVADO_PATH}/settings64.sh # DELETE THIS LINE
  # Setup variables for synthesis. You may need to change this based on your FPGA board.
  export FPGA_PART=xc7a35tcpg236-1
  export PS1="☕ $PS1"
}

# Uncomment this if you aren't using this Linux install for any other projects.
# setup_cafe;
```

## Check the Installation
Close your terminal and open a fresh one (this will re run .bashrc, you can also run `source ~/.bashrc` in your current terminal. To set up the environment, run `setup_cafe`, you should now see a little `☕` emoji at 
the start of your prompt. Make sure you are in this repos directory, then run `./tools/check_install`.

If you get an error saying that `Python library bitstring not installed.`, and if `⦗OSS CAD Suite⦘` is in your prompt, you can run `pip3 install bitstring` to resolve that issue. You should only need to do this once.