# Instructor TODOs:
- [ ] add this trick to cheatsheet: `make test_rv32i_peripherals 2>&1 | grep -v 'constant selects in always'` since `-Wno-sensitivity-entire-array` doesn't seem to work.
- [ ] add `[i*8 +:8]` bus addressing to cheatsheet if both vivado and icarus support it.
- [ ] consolidate hierarchy: separate components/systems idea didnt' really work well. One (large) makefile (with direct includes) with a flattend directory is a better approach.
- [ ] update all Makefiles to include ```IVERILOG=iverilog -Wall -Wno-sensitivity-entire-vector 
    - also add SHELL=/usr/bin/bash to the top
- [ ] fix sync script
- [ ] do a full pass to replace derived parameters with `localparam`
- [ ] change include files to packages (if iverilog & vivado supports it)
- [ ] all readmemh's seem to be able to fail silently this year, really odd.
- [ ] risc-v nanorc file
- [ ] have a clear place in the lab submissions for student's names to go. Add to intro slides for the course.
- [ ] check all make submission targets and make sure they work standalone! Maybe automate?

## Tools
- [ ] Look into what it would take to patch Icarus Verilog on the following:
  - [ ] Remove the `constant selects in always` error with better `always_comb` support.
  - [ ] Better support for type casting.
  - [ ] interfaces (top priority for comparch ii).
- [ ] Use open source tools for area/critical path analysis.
- [ ] Open source fpga synthesis?
- [ ] script to generate gtkwave text filters from verilog
  - [ ] oooh or single script that live translates based on found verilog enums? 
- [ ] ~or~ scipt to generate verilog enums and text filters from python? More painful overall, could get confusing.
- [ ] vivado tcl script improvements
  - [ ] look into this to use asserts to fail synthesis? `set_property STEPS.SYNTH_DESIGN.ARGS.ASSERT true [get_runs synth_1]`

## Lab 1: Conway's Game of Life

## Lab 2: Etch A Sketch
- [ ] add an i2c accelerometer for erasing by shaking
- [ ] add two encoders for real etch a sketch.
  - [ ] add tb that does a spiral assuming encoder input
- [ ] initialize VRAM with an image
- [ ] find a way to dump and visualize vram
- [ ] progress indicator in testbench is off.
- [ ] consider moving or dropping this lab next time.

## Lab 3: CPU
- [x] bug: disassembler thinks srai is srli
- [x] make sure latest version of lab 2 peripherals is there
- [x] have a structural optimized ALU in the solutions
  - [ ] with a carry look ahead? prefix? Options?
- [...] double check rom/ram files
- [x] task to dump memory
- [ ] double check instruction checklist
- [ ] unit tests to make sure system works.
- [ ] single step mode
- [ ] visualize r-file, PC, state on display
  - [ ] touch buttons to change mode? 

## Lab 4: Advanced CPU
- [ ] peripheral test
  - [ ] led fading with timer
  - [ ] gpio based conway leds
  - [ ] vram based conway display
    - [ ] alternative: update ili driver to work as an async memory unit.
  - [ ] touch based etch a sketch
  - [ ] uart hello world
  - [ ] uart as programmer (arduino-ify)
- [ ] assembler updates
  - [ ] data storage
  - [ ] .text type directives
  - [x] support for instructions spread over a new line (label and instruction separate)
  - [ ] support for semicolon based separation?
  - [ ] replace `parsed["instruction"]` etc. with a dataclass
  - [ ] support hex in offsets/constants
- [ ] async mmu & updated multicycle cpu
- [ ] use external memory
  - [ ] external issi sram
  - [ ] external SPI flash
  - [ ] L1 cache (i or d)
- [ ] interrupt controller
- [ ] sleep modes
- [ ] pipelined cpu
  - [ ]  branch prediction
- [ ] M extension
- [ ] D extension
- [ ] RTOS (maybe [freertos](https://www.freertos.org/Using-FreeRTOS-on-RISC-V.html))
