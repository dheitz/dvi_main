#!/usr/bin/env python3

import glob
import os
import os.path
import shutil


def transfer_file(fn, out_fn):
    delimiters = ["// SOLUTION START", "// SOLUTION END"]
    if (
        fn.endswith("Makefile")
        or fn.endswith(".py")
        or fn.endswith(".xdc")
        or fn.endswith(".md")
    ):
        delimiters = ["# SOLUTION START", "# SOLUTION END"]
    with open(fn, "r") as f:
        with open(out_fn, "w") as f2:
            print(f"syncing {fn} to {out_fn}")
            cut_out = False
            for line in f:
                if cut_out:
                    if delimiters[1] in line:
                        cut_out = False
                        continue
                else:
                    if delimiters[0] in line:
                        cut_out = True
                        continue
                    f2.write(line)


def main(src_dir="./", dest_dir="/home/avinash/src/olin-cafe-f22"):
    print("WARNING!!! This script is real broken right now.")
    for src, dst in [("labs/02_etch_a"]:
        # for folder in ["hws/fa22/4"]:
        # for folder in ["labs/01_game_of_life"]:
        local_dest_dir = os.path.abspath(os.path.join(dest_dir, dst))
        print(f"copying to {local_dest_dir}")
        if not os.path.exists(local_dest_dir):
            print(f"creating local_test_dir {local_dest_dir}")
            os.makedirs(local_dest_dir, exist_ok=True)

        fns_to_sync = []
        for pattern in [
            f"{src}/*.md",
            f"{src}/*.tcl",
            f"{src}/*.xdc",
            f"{src}/*.sv",
            f"{src}/hdl/*.sv",
            f"{src}/tests/*.sv",
            f"{src}/Makefile",
            f"{src}/*.gtkw",
            f"{src}/*.memh",
            f"{src}/docs/*",
            f"{src}/hdl/*",
            f"{src}/tests/*",
        ]:
            fns_to_sync.extend(glob.glob(pattern))
        for fn in fns_to_sync:
            out_fn = os.path.join(dest_dir, fn)
            print("...fn", fn, "->", out_fn)
            if any(
                [
                    fn.endswith(x)
                    for x in [
                        ".sv",
                        ".py",
                        ".xdc",
                        ".md",
                        "Makefile",
                        ".memh",
                        ".memb",
                    ]
                ]
            ):
                transfer_file(fn, out_fn)
            else:
                shutil.copyfile(fn, out_fn)


if __name__ == "__main__":
    main()
