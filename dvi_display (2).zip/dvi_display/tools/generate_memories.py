#!/usr/bin/env python3

import argparse

_fibonacci_cache = {0: 0, 1: 1}
def fibonacci(x):
    if x in _fibonacci_cache:
        return _fibonacci_cache[x]
    _fibonacci_cache[x] = fibonacci(x-1) + fibonacci(x-2)
    return _fibonacci_cache[x]


def generate_fibonacci(fn="memories/fibonacci.memh", L=48, W=8):
    print(f"Writing fibonacci sequence to {fn}.")
    with open(fn, 'w') as f:
        for i in range(L):
            d = fibonacci(i)
            if d > 2**W-1:
                raise Exception(f"fibonacci({i}) does not fit in width {W}.")
            f.write("%08x\n" % fibonacci(i))
    print(f"Wrote {L}x{W} to {fn}.")

def generate_squares(fn="memories/squares.memh", L=64, W=8):
    print(f"Writing fibonacci sequence to {fn}.")
    with open(fn, 'w') as f:
        for i in range(L):
            f.write("%08x\n" % i**2)
    print(f"Wrote {L}x{W} to {fn}.")

def generate_zeros(fn="memories/zeros.memh", L=64, W=8):
    print(f"Writing fibonacci sequence to {fn}.")
    with open(fn, 'w') as f:
        for i in range(L):
            f.write("%08x\n" % 0)
    print(f"Wrote {L}x{W} to {fn}.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--memory', choices=['fibonacci', 'squares', 'zeros'])
    parser.add_argument('--length', type=int, default=64) 
    parser.add_argument('--width', type=int, default=8, choices=[8,16,32,64]) 
    parser.add_argument('--out')

    args = parser.parse_args()
    if not args.out:
        return
    elif args.memory == 'fibonacci':
        generate_fibonacci(fn=args.out, L=args.length, W=args.width)
    elif args.memory == 'squares':
        generate_squares(fn=args.out, L=args.length, W=args.width)
    elif args.memory == 'zeros':
        generate_zeros(fn=args.out, L=args.length, W=args.width)
      

if __name__ == "__main__":
    main()
