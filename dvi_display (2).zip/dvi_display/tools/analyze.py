#!/usr/bin/env python

import click
import os
import os.path as path
import re
import subprocess
import tempfile

simple_cmos_example = """
read_verilog counter.v
read_verilog -lib cmos_cells.v

synth
dfflibmap -liberty cmos_cells.lib
abc -liberty cmos_cells.lib
opt_clean

stat -liberty cmos_cells.lib

# http://vlsiarch.ecen.okstate.edu/flows/MOSIS_SCMOS/latest/cadence/lib/tsmc025/signalstorm/osu025_stdcells.lib
# dfflibmap -liberty osu025_stdcells.lib
# abc -liberty osu025_stdcells.lib;;

write_verilog synth.v
write_spice synth.sp
-g cmos 
"""

yosys_script = """
read -sv -I{include_dir} {source_files}
read_verilog -lib -specify {cell_verilog}
hierarchy -check -top {top};
synth
clean
flatten
# dfflibmap -liberty {library}
abc -liberty {library}
# opt_clean
tee -o {top}.stats.log stat -liberty {library};
tee -a {top}.stats.log sta;
"""

current_dir = path.dirname(path.abspath(__file__))


def get_oss_location():
    loc = subprocess.check_output(["which", "yosys"]).decode("utf8")
    loc = path.dirname(path.dirname(loc))
    return loc


default_library = path.join(current_dir, "cmos.lib")
default_include_dir = path.join(current_dir, "components")
default_cell_verilog = path.join(current_dir, "cmos_cells.v")
# default_cell_verilog = path.join(get_oss_location(), "share/yosys/xilinx/cells_sim.v")


@click.command()
@click.argument("sources", nargs=-1)
@click.option("--library", type=click.Path(), default=default_library)
@click.option("--cell_verilog", type=click.Path(), default=default_cell_verilog)
@click.option("--verbose", is_flag=True, default=False)
@click.option("--debug", is_flag=True, default=False)
def analyze(sources, library, cell_verilog, verbose, debug):
    if not sources:
        return
    top_module, ext = path.splitext(path.basename(sources[0]))
    include_dirs = set([path.dirname(s) for s in sources])

    click.echo(f"Using {top_module} as the top level module:")
    click.echo(f"Source files:\n  {', '.join(sources)}")

    script = yosys_script.format(
        source_files=" ".join(sources),
        top=top_module,
        library=library,
        cell_verilog=cell_verilog,
        include_dir=default_include_dir,
    )

    if verbose:
        click.echo(script)

    with tempfile.TemporaryDirectory() as working_dir:
        script_fn = path.join(working_dir, "analysis.ys")
        with open(script_fn, "w") as f:
            f.write(script)
        if debug:
            with open("./debug.ys", "w") as f:
                f.write(script)
        results = subprocess.check_output(["yosys", "-s", script_fn])
        area = -1
        critical_path = -1
        results = results.decode("utf-8")
        for line in results.split("\n"):
            print(f"{line=}")
            m = re.search("Chip area for module.*?(\d+\.\d+)", line)
            if m:
                area = float(m.group(1))
            m = re.search("Latest arrival time in .* is (\d+)", line)
            if m:
                critical_path = float(m.group(1))
        print("\n" * 3)
        print("#" * 40)
        print(f"# Summary for {top_module}, see {top_module}.stats.log for details.")
        print(f"### {area=}")
        print(f"### {critical_path=}")
        print(f"# Check {top_module}.stats.log for details.")
        print("#" * 40)


if __name__ == "__main__":
    analyze()
