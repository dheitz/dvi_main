#!/usr/bin/env python3
USAGE = """tools/grader.py
Run from the top level git directory for all the paths to work.
Note, you should set your EDITOR envar to something you like using. I use nano, and have a custom nanorc file for systemverilog in this repo that makes grading a cinch.


Known bugs:
- Sometimes need to Ctrl+Z then kill %{processnum} to get out in the middle of grading.
- macos includes .pdfs in some metadata that can't be opened by my viewer, you can just close those to proceed.
- Can't handle an extra dir in the zip (e.g. submission.zip/submission/blah). Could search for the Makefile and use that as the base dir?
- gtkwave prompt isn't great, should make it a menu. Or just have all the assignments require a waves_foo target.
"""

import click
import contextlib
import glob
import os
import os.path as path
import pathlib  # TODO(avinash) learn how to use pathlib to replace os, os.path
import shutil
import subprocess
import tempfile
import zipfile
from dataclasses import dataclass, field


@dataclass
class AssignmentParameters:
    # List of make targets that you want to run.
    targets: list[str] = field(default_factory=lambda: [])
    # List of files that you don't want to look at. Currently only for hdl sources, but might extend it to all of the filters. # noqa
    exclude: list[str] = field(default_factory=lambda: [])
    # Set to true to manually go through each HDL file.
    check_hdl: bool = False
    # Set to true to manually go through each file in tests/test_*.sv.
    check_tests: bool = False
    # Set to true for a (verbose) prompt that will let you look at waveforms after any target.
    check_waves: bool = False
    # Open a terminal in the directory for manual testing.
    open_terminal: bool = False
    # A list of commands to run to fix errors in a submission (e.g. copying missing files, etc.). Assume the commands will be formatted with "working_dir" passed as a format parameter.
    hacks: list[str] = field(default_factory=lambda: [])


assignments = {
    "lab0": AssignmentParameters(targets=(), exclude=()),
    "lab1": AssignmentParameters(
        targets=["test_conway_cell", "test_main"],
        exclude=[
            "led_array_model.sv",
            "initial_conditions.sv",
            "adder_n.sv",
            "main.sv",
        ],
        check_hdl=True,
    ),
    "lab2": AssignmentParameters(
        targets=[
            "test_pulse_generator",
            "test_pwm",
            "waves_triangle_generator",
            "waves_spi_controller",
            "waves_i2c_controller",
            "test_main",
        ],
        exclude=[
            "block_ram.sv",
            "spi_types.sv",
            "block_rom.sv",
            "i2c_types.sv",
            "ft6206_controller.sv",
            "ili9341_defines.sv",
            "ft6206_defines.sv",
            "ili9341_display_controller.sv",
        ],
        hacks=[
            "cp /home/avinash/src/cafe-instructors/labs/02_etch_a_sketch/generate_memories.py {working_directory}",
            "mkdir -p {working_directory}/memories",
        ],
        check_hdl=True,
        check_waves=False,
    ),
    "hw5": AssignmentParameters(
        targets=[
            "test_comparators",
            "waves_comparator",
            "waves_pulse_generator",
            "waves_triangle_generator",
            "waves_pwm",
        ],
        exclude=[
            "adder_1.sv",
            "adder_n.sv",
            "mux4.sv",
        ],
        check_hdl=True,
        check_waves=False,
        open_terminal=True,
    ),
}


# Returns list of folders in unpacked workspace
def unpack_submission_zip(full_zip, workspace):
    if not path.exists(full_zip):
        raise FileNotFoundError(f"{full_zip} does not exist.")
    if not path.exists(workspace):
        os.makedirs(workspace)
    if not path.isdir(workspace):
        raise Exception(f"workspace not a directory: {workspace}")

    with zipfile.ZipFile(full_zip, "r") as zip_f:
        zip_f.extractall(workspace)
    results = []
    cwd = os.getcwd()
    os.chdir(workspace)
    for zip_fn in glob.glob("*.zip"):
        base, ext = path.splitext(zip_fn)
        dest = path.join(workspace, base)
        try:
            os.mkdir(dest)
        except FileExistsError:
            pass

        with zipfile.ZipFile(zip_fn, "r") as zip_f:
            zip_f.extractall(dest)
            results.append(dest)
    os.chdir(cwd)
    return results


def unpack_single_zip(zip_fn, workspace):
    if not path.exists(zip_fn):
        raise FileNotFoundError(f"{zip_fn} does not exist")
    try:
        os.mkdir(workspace)
    except FileExistsError:
        pass

    with zipfile.ZipFile(zip_fn, "r") as zip_f:
        zip_f.extractall(workspace)
        return workspace


def find_by_extension(top, extensions):
    for dir, dirs, fns in os.walk(top):
        for fn in fns:
            for extension in extensions:
                if fn.lower().endswith(extension.lower()):
                    yield os.path.join(dir, fn)


def grade_single(assignment, parameters):
    forked = []
    os.chdir(assignment)
    click.secho(f"Opening {assignment} for grading:", fg="green")

    os.chdir(assignment)
    if os.path.exists("GRADED"):
        click.echo(f"Already graded, skipping {assignment}.")
        return 0
    if not click.prompt("Ready to start?"):
        return
    for hack in parameters.hacks:
        hack = hack.format(working_directory=assignment)
        click.prompt(f"Apply hack? `{hack}`")
        subprocess.check_call(hack.split())
    docs_found = False
    for md in find_by_extension("./", [".md", ".txt"]):
        click.echo(f"Opening up markdown doc {md} for editing...")
        click.edit(filename=md)
        docs_found = True
    for pdf in find_by_extension("./", [".pdf"]):
        click.echo(f"Opening up pdf doc {pdf} for editing...")
        proc = subprocess.Popen(["xournalpp", pdf])
        forked.append(proc)
        # subprocess.run(["xournalpp", pdf])
        docs_found = True

    if not docs_found:
        click.secho(
            f"{assignment} has no pdfs, no markdowns.", fg="red"
        )  # noqa
    images = list(find_by_extension("./", [".png", ".jpg", ".jpeg"]))
    if images and click.confirm(
        f"Check the following images? {','.join(images)}"
    ):
        for image in images:
            subprocess.run(["eog", image])
    videos = list(
        find_by_extension(
            "./", [".mp4", ".mpeg", ".avi", ".mkv", ".mov", ".webm"]
        )
    )
    if videos and click.confirm(
        f"Watch the following videos? {','.join(videos)}"
    ):
        for video in videos:
            subprocess.run(["vlc", video])

    for i, target in enumerate(parameters.targets):
        if click.confirm(f"about to test {assignment}:{target}, continue?"):
            res = subprocess.run(["make", target])
            click.echo(f"\n return code is {res.returncode}")
            if parameters.check_waves:
                waves = list(find_by_extension("./", [".fst"]))
                if waves:
                    if click.confirm("Run gtkwave?"):
                        wave = waves[0]
                        if len(waves) > 1:
                            wave = click.prompt(
                                "Select wave file:",
                                type=click.Choice(choices=waves),
                                show_choices=True,
                            )
                        subprocess.run(["gtkwave", wave])
    if parameters.check_hdl and click.confirm("Ready to check HDL?"):
        svs = find_by_extension("./hdl", [".sv"])
        if not svs:
            click.secho("Warning - found no hdl files!", fg="red")
        if parameters.check_tests:
            svs.extend(find_by_extension("./tests", [".sv"]))
        for sv in svs:
            bpath, sv_fn = path.split(sv)
            if sv_fn in parameters.exclude:
                continue
            click.edit(filename=sv)
    if parameters.open_terminal:
        subprocess.run(["xfce4-terminal", assignment])

    if click.confirm("Ready to call this assignment graded?"):
        pathlib.Path("GRADED").touch()

    for proc in forked:
        proc.terminate()


def grade_all(full_zip, workspace, parameters):
    assignments = unpack_submission_zip(full_zip, workspace)
    for i, assignment in enumerate(assignments):
        click.echo(f"Grading assignment {i+1}/{len(assignments)}.")
        try:
            grade_single(assignment, parameters)
        except KeyboardInterrupt:
            click.echo(
                "Wrapping up. You can resume by running the same command."
            )
            return 0
        except Exception as e:
            click.secho(
                f"\nSome uncaught error on submission {assignment}.\n\n{e}\n\n",
                fg="red",
            )
            return 1


@click.command()
@click.option(
    "--assignment", default=None, type=click.Choice(assignments.keys())
)
@click.option(
    "--submission",
    type=str,
    default=None,
    help="Zip containing submission(s).",
)
@click.option("--workspace", type=str, default=None, help="Working directory.")
@click.option(
    "--single",
    is_flag=True,
    default=False,
    help="Use this flag if grading a single submission (not a downloaded zip of many).",
)
def main(assignment, submission, workspace, single):
    click.echo(
        f"Starting grading of assingment {assignment}, submission {submission}"
    )
    parameters = assignments[assignment]

    if workspace is None:
        workspace = os.path.splitext(submission)[0]
    workspace = path.abspath(workspace)
    if single:
        assignment = unpack_single_zip(submission, workspace)
        return grade_single(assignment, parameters)
    return grade_all(submission, workspace, parameters=parameters)


if __name__ == "__main__":
    main()
