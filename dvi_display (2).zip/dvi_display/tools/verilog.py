#!/usr/bin/env python

"""
TODO(avinash)
* [ ] bug: does not handle commented out anything (need external tool to remove comments).
* [ ] bug: doesn't copy localparams for testbench generation.
* [ ] bug: doesn't copy includes
* [ ] feature: add enum to gtkwave txt file support
"""

import argparse
import re
from numpy import log2, ceil
import datetime
import click

HEADER = """`default_nettype none\n`timescale 1ns/1ps\n"""
FOOTER = """"""


# Used [T Raylor's summary slide deck](https://web.engr.oregonstate.edu/~traylor/) to help write these regexes.
_re_verilog_literal = re.compile(r"(?P<sign>\-)?(?P<radix_and_width>\d*?'[bohd])?(?P<value>[0-9a-fA-F_]+)")
_re_radix_width = re.compile(r"(?P<width>\d*)?'(?P<radix>[bohd])")
RADIX_TO_NUMBER = {'b':2, 'o':8, 'd':10, 'h':16}

def parse_literal(verilog_literal):
    m = _re_verilog_literal.match(verilog_literal)
    if not m:
        raise ValueError(f"'{verilog_literal} not a valid verilog literal")
    
    # Default to 32 bit decimal.
    radix = 'd'
    width = 32 
    if m.group('radix_and_width'):
        m_rw = _re_radix_width.match(m.group('radix_and_width'))
        if m_rw.group('width'):
            width = int(m_rw.group('width'))
        radix = m_rw.group('radix')
    value = m.group('value')
    value.replace("_", "")
    value = int(value, RADIX_TO_NUMBER[radix])
    if radix == 'b':
        value = int(value, 2)
    elif radix == 'd':
        value = int(value, 10)
    elif radix == 'o':
        value = int(value, 8)
    elif radix == 'h':
        value = int(m.group('value'), 16)

    if m.group('sign'):
        value = -1*value
    return value

def parse_enum(verilog_enum):
    raise NotImplementedError()

def clog2(x):
    return int(ceil(log2(x)))

re_module_start = re.compile(r"module\s+(?P<name>\w+)[^;]*?;")
re_port = re.compile(
    r"(?P<direction>input|output|inout)\s+(?P<net_type>\w+)\s+(?P<bus>\[.+?\])?(?P<nets>[,\w\s]+);"
)
re_parameter = re.compile(
    r"parameter\s+(?P<name>\w+)\s*(=\s*(?P<default>[^;]*?))?;"
)

parser = argparse.ArgumentParser(
    description="generates code base on a verilog module"
)
parser.add_argument(
    "module",
    type=argparse.FileType("r"),
    help="file with the module that will be used to generate a testbench",
)
parser.add_argument(
    "--instantiate", "-i", type=str, help="instance name to generate"
)
parser.add_argument(
    "--instantiate_with_names",
    "-n",
    action="store_true",
    help="use the name of the port as its input name too",
)
parser.add_argument(
    "--testbench",
    "-t",
    action="store_true",
    help="generate a testbench for the module",
)
parser.add_argument(
    "--waves",
    "-w",
    action="store_true",
    help="add wave dump capability to the testbench",
)

PORT_DIRECTIONS = ["input", "output", "inout"]
VALID_NET_TYPES = ["wire", "reg", "logic", "integer"]


def validate_identifier(i):
    i = i.strip()
    for c in " .-":
        i = i.replace(c, "_")
    return i


class VerilogParseException(Exception):
    def __init__(self, msg):
        Exception.__init__(self, "VPE:" + msg)

_custom_types = set()
class Net:
    def __init__(
        self, name, width=None, net_type=None, signed=False, default=None
    ):
        self.name = validate_identifier(name)
        self.i_width = 1
        if width is None:
            width = ""
        elif hasattr(width, "__int__"):
            if width > 32:
                print(
                    f"WARNING: reducing width of net '{self.name}' from {width} to 32"
                )
                width = 32
            self.i_width = width
            if width > 1:
                width = f"[{width-1}:0]"
            else:
                width = ""
        self.width = width
        # The one time I like `default_nettype wire.
        if net_type is None:
            net_type = "wire"
        if net_type not in VALID_NET_TYPES:
            if net_type not in _custom_types:
                print(f"WARNING: assuming '{net_type}' is a custom type.")
                _custom_types.add(net_type)
        self.net_type = net_type

        self.signed = ""
        if signed:
            self.signed = " signed"
        self.default = default

    def is_one_wire(self):
        return (self.width == "") or (self.i_width == 1)

    def instantiate(self):
        if self.net_type in ["reg", "logic", "integer"]:
            if self.default is not None:
                return f"{self.net_type}{self.signed} {self.width} {self.name} = {self.default};"
        return f"{self.net_type}{self.signed} {self.width} {self.name};"

    def __str__(self):
        return self.name

    def __eq__(self, other):
        return (
            self.name == other.name
            and self.width == other.width
            and self.net_type == other.net_type
            and self.signed == other.signed
            and self.default == other.default
        )


class Port(Net):
    def __init__(
        self, name, direction, width=None, net_type=None, signed=False
    ):
        Net.__init__(
            self,
            name,
            width=width,
            net_type=net_type,
            signed=signed,
            default=None,
        )
        if direction not in PORT_DIRECTIONS:
            raise VerilogParseException(
                f"direction '{direction}' is not a valid direction"
            )
        self.direction = direction

    def connect(self, net=None):
        if net is None:
            net = self.name
        return f".{self.name}({net})"

    def instantiate(self):
        return f"{self.direction} {self.net_type} {self.width} {self.name}"


def port_to_net(port, name=None, force_wire=True):
    if name is None:
        name = port.name
    net_type = "logic"
    if port.direction == "output" or force_wire:
        net_type = "wire"
    return Net(
        name=name,
        width=port.width,
        net_type=net_type,
        signed=port.signed,
        default=port.default,
    )


class Parameter:
    def __init__(self, name, default=None):
        self.name = name
        self.default = default

    def connect(self, value=None):
        if value is None:
            if self.default is None:
                value = "0"
            else:
                value = self.default
        return f".{self.name}({value})"

    def __str__(self):
        return f".{self.name}({self.default})"

    def instantiate(self):
        return f"parameter {self.name} = {self.default};"


"""
    -parses verilog source files to read in modules and the necessary ports and parameters
    -generates:
        module instantiation code
        connection/interface code
        testbench code
"""


class Module:
    def __init__(self, name, body=None):
        self.name = name
        self.ports = []
        self.parameters = []
        if body is None:
            body = ""
        self.body = body

    def __str__(self):
        return """Module %s\nparameters:\n  %s\nports:\n  %s\n""" % (
            self.name,
            "\n  ".join([str(p) for p in self.parameters]),
            "\n  ".join([str(p) for p in self.ports]),
        )

    def has_port(self, port_name):
        return port_name in [p.name for p in self.ports]

    def get_port(self, port_name):
        ports = [p for p in self.ports if p.name == port_name]
        if ports:
            return ports[0]
        return None

    def testbench(
        self,
        waves=False,
        timeout=None,
        initial_src=None,
        extra_src=None,
        do_not_drive=None,
    ):
        if do_not_drive is None:
            do_not_drive = []
        lines = []
        connections = []
        initials = []

        lines.append(HEADER)
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines.append(f"// Auto-generated on {timestamp}\n")
        lines.append(f"module test_{self.name};")

        parameter_connections = {}
        if self.parameters:
            lines.append("\n")
            for parameter in self.parameters:
                lines.append(parameter.instantiate())
                parameter_connections[parameter.name] = parameter.name
            lines.append("\n")

        # Create nets found in the UUT.
        initials = []
        lines.append("// UUT IO")
        for port in self.ports:
            new_type = "wire"
            if port.direction == "input" and port.name not in do_not_drive:
                new_type = "logic"
                initials.append(port.name)
            lines.append(f"{new_type} {port.width} {port.name};")

        # Instantiate UUT.
        lines.append("\n")
        lines.append(
            self.instantiate(
                "UUT", connections="default", parameters=parameter_connections
            )
        )

        if extra_src:
            lines.append(extra_src)

        # Initialize any module inputs.
        lines.append("\ninitial begin")
        lines.append("\n".join(["  %s = 0;" % x for x in initials]))

        # waves
        if waves:
            lines.append("")
            lines.append(f"""  $dumpfile("{self.name}.fst");""")
            lines.append("  $dumpvars(0, UUT);")
        if initial_src is not None:
            lines.append(initial_src)
        lines.append("  $finish;")
        lines.append("end")

        if timeout is not None:
            lines.append(
                f'initial begin\n  #({timeout}) $display("Error: Timed out!!!");\n  $finish;\nend'
            )
        lines.append("\nendmodule")
        lines.append(FOOTER)
        return "\n".join(lines)

    def instantiate(
        self, instance_name, connections=None, prefix="", parameters=None
    ):
        lines = []
        if parameters:
            lines.append(f"{self.name} #(")
            lines.append(
                ",\n".join(
                    [
                        f"  {p.connect(parameters[p.name])}"
                        for p in self.parameters
                        if p.name in parameters
                    ]
                )
            )
            lines.append(f") {instance_name} (")
        else:
            lines.append(f"{self.name} {instance_name} (")

        if connections == "default":
            lines.append(
                ",\n".join(
                    [f"  .{p.name}({prefix + p.name})" for p in self.ports]
                )
            )
        elif hasattr(connections, "has_key"):
            for p in self.ports:
                if not connections.has_key(p.name):
                    connections[p.name] = ""
            lines.append(
                ",\n".join(
                    [f"  .{p.name}({connections[p.name]})" for p in self.ports]
                )
            )
        elif connections is None:
            lines.append(",\n".join([f"  .{p.name}()" for p in self.ports]))

        lines.append(");")
        return "\n".join(lines)


def src_to_module(src):
    original_src = src
    
    # Find parameter declaration.
    m = re_module_start.search(src)
    if not m:
        raise Exception("file did not have a module declaration!")
    module_name = m.group("name")
    module_start = m.end()
    module_end = src.find("endmodule")

    module = Module(module_name, original_src)

    if module_end == -1:
        src = src[module_start:]
    else:
        src = src[module_start:module_end]
    ports = re_port.findall(src)
    for direction, net_type, width, names in ports:
        for name in names.split(","):
            name = name.strip()
            module.ports.append(Port(name, direction, width, net_type))

    parameters = [
        (m.group("name"), m.group("default"))
        for m in re_parameter.finditer(src)
    ]
    for name, default in parameters:
        module.parameters.append(Parameter(name, default))
    return module


def fn_to_module(fn):
    with open(fn, "r") as f:
        return src_to_module(f.read())



@click.command()
@click.argument("module")
@click.option("-i", "--instantiate", default="UUT", help="")
@click.option("-t", "--testbench", is_flag=True, default=False, help="")
@click.option("-n", "--names", is_flag=True, default=False, help="")
@click.option("-p", "--parameters", is_flag=True, default=False, help="")
@click.option("-w", "--waves", default="dump.fst", help="")
@click.option("-c", "--clk", is_flag=True, default=False, help="")
@click.option("-f", "--fpga", is_flag=True, default=False, help="")
def verilog(module, instantiate, testbench, names, parameters, waves, clk, fpga):
    if not (instantiate or testbench):
        raise Exception("pick -t or -i to use this script properly")

    src = ""
    with open(module, 'r') as f:
        src = f.read()
    mod = src_to_module(src)

    if testbench:
        print(mod.testbench(waves=waves))
    if instantiate:
        if names:
            print(mod.instantiate(instantiate, connections="default"))
        else:
            print(mod.instantiate(instantiate))

if __name__ == "__main__":
    verilog()