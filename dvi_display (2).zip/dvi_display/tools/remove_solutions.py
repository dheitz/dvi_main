#!/usr/bin/env python3

import glob
import os
import os.path
import shutil

import click


def clear_file(fn):
    omit_file_flag = "// SOLUTION_OMIT_FILE"
    delimiters = ["// <<<SOLUTION", "// SOLUTION>>>"]
    if (
        fn.endswith("Makefile")
        or fn.endswith(".py")
        or fn.endswith(".xdc")
        or fn.endswith(".md")
    ):
        delimiters = ["# <<<SOLUTION", "# SOLUTION>>>"]
        omit_file_flag = "# SOLUTION_OMIT_FILE"
    buffer = []
    solutions_found = False
    omit_file = False
    with open(fn, "r") as f:
        cut_out = False
        for line in f:
            if omit_file_flag in line:
                omit_file = True
                break
            if cut_out:
                print(f"<<< {line.strip()}")
                if delimiters[1] in line:
                    cut_out = False
                    continue
            else:
                if delimiters[0] in line:
                    cut_out = True
                    solutions_found = True
                    continue
                buffer.append(line)
    if omit_file:
        print(f">>> omitted (rm'd) {fn}")
        os.remove(fn)
        return
    if solutions_found:
        with open(fn, "w") as f2:
            for line in buffer:
                f2.write(line)
        print(f">>> removed solutions from {fn}")


special_file_extensions = [
    "Makefile",
    ".py",
    ".xdc",
    ".md",
    ".sv",
    ".v",
    ".gtkw",
    ".tcl",
    ".memh",
    ".memb",
]


@click.command()
@click.argument("path")
def remove_solutions(path):
    for dirpath, dirnames, fns in os.walk(path):
        for fn in fns:
            if fn[0] == ".":
                continue
            elif any([fn.endswith(ext) for ext in special_file_extensions]):
                full_fn = f"{dirpath}/{fn}"
                click.echo(f"!!! removing solutions from {full_fn} ")
                clear_file(full_fn)


if __name__ == "__main__":
    remove_solutions()
