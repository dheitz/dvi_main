#!/bin/bash

USAGE="./custom_install /PATH/TO/INSTALL \
Or to install everything, do:
./custom_install /PATH/TO/INSTALL full
"


if [ $# -ge 3 ] || [ $# -eq 0 ] ; then
  echo "Takes at least one argument, the path to install Xilinx Vivado."
  exit 1
fi

if [ -e $1 ] ; then
  echo "ERROR: directory '$1' already exists. Contact an instructor if you are trying to repair an existing install."
fi

RSYNC_OPTS="-rlptgoE --safe-links --info=progress2,skip1"

if [ $# -eq 2  ] && [ $2 == "full" ] ; then
  rsync ${RSYNC_OPTS} ./full_install $1
else 
  rsync ${RSYNC_OPTS} --exclude-from='exclude_list.txt' ./full_install $1
fi
# note Vivado/2022.1/data/parts/xilinx/virtex7 used to be in exclude list, that causes problems.
chown -R $USER $1
chgrp -R $USER $1