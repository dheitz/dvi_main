#!/usr/bin/env python3
import argparse
from bitstring import BitArray
from io import UnsupportedOperation
import os.path as path
import sys
import rv32i

import numpy as np

try:
    import cv2
except ImportError:
    print("install opencv TODO(avinash) include ubuntu instrucitons")
    sys.exit(0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", help="input memory file")
    parser.add_argument(
        "-x", default=320, type=int, help="x resolution of display"
    )
    parser.add_argument(
        "-y", default=240, type=int, help="y resolution of display"
    )
    parser.add_argument(
        "-scale", default=1, type=int, help="Down scale factor."
    )
    args = parser.parse_args()
    if not path.exists(args.input):
        raise Exception(f"input file {args.input} does not exist.")

    buffer = []
    with open(args.input, "r") as f:
        for i, line in enumerate(f):
            if line.startswith("//"):
                continue
            if "x" in line.lower():
                continue
            buffer.append(int(line.strip(), 16))
    w = args.x // args.scale
    h = args.y // args.scale
    L = w * h
    if len(buffer) < L:
        print(
            "Warning: VRAM does not have enough data, "
            f"only {len(buffer)} rows instead of {L}"
        )
        buffer.extend([0] * (L - len(buffer)))
    array = np.asarray(buffer, dtype=np.uint16)
    image = cv2.imdecode(array, cv2.CV_16UC3)
    if not image:
        return -1
    print(image.shape)
    cv2.imshow("Image", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
