# CAFE - Computer Architecture FPGA Edition

By email to avinash+olin@nonhlonomy.com

Subject must be [cafe2] [final project submission]

cc all team members

If the submission is a github link, it must include the commit hash so that I can verify that I am looking at what was done by the deadline. Zips/tarballs are always good as well.

Whatever the submission, it should be tested. If you can’t do a fresh clone/fresh unzip and have it work, that will reflect poorly.
Documentation

In the form of txt, markdown, or PDF inside your submission. No links to google docs! I have to submit some of this for accreditation purposes, do not make me attempt to download PDFs from broken links. 

Sufficient description (block diagram/text) of all of the components in the project and how they are connected.

A description of how to test that things should work without any attached hardware (e.g. toolchain checks, a simulation to run with a description or waveform screenshot of expected results).

For hardware projects, a description of how to set up any hardware required and run a test.

Wiring diagrams, pictures of setups, descriptions of software (if any) that needs to be running, any specific data or test inputs required.
How to run tests that show what your system does. 

Descriptions (text, image, or video) of how a working system should behave.

Process Documentation
A copy of your original proposal.

A description of what MVP you set out to achieve that I last agreed on.

A brief description of your design process.

What design, test, and iterate steps did you go through? 

For teams: 
Who worked on which component of the system.

What was your integration and test plan? What challenges (if any) did you face? What worked well?

(Optional, but encouraged) If you had to do this project again, what would you do differently?

(each team member can answer this separately if you want).



## TODOS:
- [x] add cocotb testing infrastructure
- [ ] [OSS Cad Suite](https://github.com/YosysHQ/oss-cad-suite-build) as default install now, should update all docs
- [ ] Formal Verification (sby? abc?) [yosys risc-v example](https://github.com/YosysHQ/riscv-formal/tree/main)
- [ ] amaranth as an sv replacement
- [ ] C -> custom rv32i
    - [ ] memory mapping
    - [ ] compilation

## Cheatsheet TODOs:
- [ ] Shift registers: explain that this doesn't work, even though it should: `rx_buffer<= {rx_buffer[DATA_BITS-1:1], uart_rx_i_synced};`

Before S24:
- [ ] Check out [TerosHDL](https://terostechnology.github.io/terosHDLdoc/about/about.html)
- [ ] Something on WebAssembly? Could be interesting for [yowasp](https://yowasp.org/) too. 
- [ ] opensta

Whenever: 
- [ ] Unit testing ([vunit](https://vunit.github.io/)?)
- [ ] Check out [edalize](https://github.com/olofk/edalize)
    - [*] the [video](https://www.youtube.com/watch?v=HuRtkpZqB34) is amazing. 
    - [ ] potential for remote building? cross-FPGA support? SoC support?
    - [ ] send students to WOSET? Seems to be in November
- [ ] Find a VHDL expert to translate labs to VHDL.
- [ ] Port labs to Amaranth or other modern HDL. 

## Instructor Install Guide

I don't support Windows, but most of this *should* work on Windows Subsystem for Linux (works fine in Windows 10, completely untested on Windows 11). I've had students get everything but Xilinx working in macos too (a lot of the open source tool devs use macs), but your mileage will vary for a bit on the newer ARM M1/M2 macs.

It's a work in progress, but I am slowly making sure everything runs in Docker containers. Right now I've only done that for Ubuntu, though I know the tools work just fine in Arch and Gentoo. Check the `containers/README.md` and `containers/*/Dockerfile`s for how to get the tools working.

In addition, you will want `inkscape` and `LaTeX` for the prettier document generation - on Debian you can get these with (untested):

```sudo apt-get install texlive-latex-base texlive-fonts-recommended texlive-fonts-extra texlive-latex-extra inkscape```


### Xilinx Notes:
Xilinx minification - tools are bloated, but seem to be getting better in 2023. Notes that are consistently true:
- Hard drive speed is the most important factor in getting synthesis to move quicker. Large SSDs make this less of an issue.

2023.x
- Hard drive usage seems to be better
    - full install: 41G. Needs a lot more space to get there so copying from a drive is still the right answer.
    - Vivado full: 35G 
        - fdupes says there are only 86MB of duplicates, not worth de-duping.
        


<2022.x
- If you do a full install of Xilinx Vivado/Vitis to an (ideally) non-root location `${full_install}`, you can use `tools/custom_install.sh` (and the associated `tools/exclude_list.txt`) to generate a much smaller image! My best efforts have gotten it down to ~26 GB from the ~75GB a full install ends up using (and way less than the ~125GB the official installer requires).
Note - this exclude list is ridiculously specific for the artix chips currently in use. There are definitely files in the non-artix architecture folders that, if omitted, cause completely opaque errors. 
- Safer way is to just de-duplicate files with symlinks (untested)

- using a tiling window manager? 
` export _JAVA_AWT_WM_NONREPARENTING=1`
